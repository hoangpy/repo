import xbmcplugin as G,xbmcgui as X,xbmc as A,json,sys as H,time,xbmcaddon as Y,urllib.parse as D
from req import get_json as Z,get
def B():
	W='path';V='icon';U='callback';T='mediatype';S='art';R='label';Q='subdir';M='info';F='fanart';C='';I=int(H.argv[1]);O=H.argv[0];a,b,h,c,a=D.urlsplit(H.argv[0]+H.argv[2]);d=dict(D.parse_qsl(c));P=d.get(Q,C);N='https://nghienkodi.deno.dev/kodi/jindex.html'
	if P!=C:N=N+'/'+D.quote(P)
	e=Z(N);f=Y.Addon().getAddonInfo(F)
	try:
		J=C;K=C
		for A in e['items']:
			E=X.ListItem(label=A[R]);B={}
			if S in A:
				B=A[S]
				if K==C and F in B:K=B[F]
				if F not in B:B[F]=f
			if M in A:
				E.setInfo('video',A[M])
				if J==C and T in A[M]:J=A[M][T]+'s'
			L=False
			if U in A:E.setProperty('IsPlayable','true');E.setPath(A[U])
			else:L=True
			if V not in B:B[V]='DefaultFolder.png'if L else'DefaultVideo.png'
			E.setArt(B)
			if W in A:g=A[W]['url'];O=D.urlunsplit(('plugin',b,'/'+D.quote(A[R]),D.urlencode({Q:g}),C))
			G.addDirectoryItem(I,O if L else E.getPath(),E,L)
		if J:G.setContent(I,J)
		if K:G.setPluginFanart(I,K)
	finally:G.endOfDirectory(I)
def C(txt):A.log(txt,A.LOGINFO)
if __name__=='__main__':B()