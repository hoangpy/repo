import json
import urllib
from urllib import request

proxy_handler = urllib.request.ProxyHandler()  # uses system proxy settings
opener = urllib.request.build_opener(proxy_handler)

def get_json(url: str, data=None, headers={}):
    with urllib.request.urlopen(request.Request(url, data, headers)) as response:
        return json.loads(response.read().decode('utf-8'))

def get(url: str, data=None):
    try:
        r = request.urlopen(url, data)
    except urllib.error.HTTPError as e:
        r = e

    return r


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


request.install_opener(request.build_opener(NoRedirect))
