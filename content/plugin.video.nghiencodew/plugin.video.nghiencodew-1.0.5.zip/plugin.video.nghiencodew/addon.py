import xbmcplugin as E,xbmcgui as e,xbmc as I,json,sys as J,time,xbmcaddon as f,json,urllib as C,base64
from urllib import request as A
import urllib.parse as F
def B():
	d='path';c='icon';b='callback';a='mediatype';Z='art';Y='items';X='plugin';W='subdir';S='/code-';P='info';O=False;H='fanart';B='';G=int(J.argv[1]);K=J.argv[0];h,T,U,i,h=F.urlsplit(J.argv[0]+J.argv[2]);j=dict(F.parse_qsl(i));k=j.get(W,B);L=B
	if U.startswith(S):L=U[len(S):]
	if k:
		Q=I.Keyboard(B,'Nhập code từ phim.nghien.workers.dev:');Q.doModal()
		if Q.isConfirmed():L=Q.getText().strip();K=F.urlunsplit((X,T,S+L,B,B));I.executebuiltin('Container.Update(%s, replace)'%K);E.endOfDirectory(G,updateListing=O,succeeded=True);return
		else:E.endOfDirectory(G,updateListing=O,succeeded=O);return
	l=bytes([104,116,116,112,115,58,47,47,110,103,104,105,101,110,107,111,100,105,46,100,101,110,111,46,100,101,118,47,107,111,100,105,47,99,111,100,101,47]).decode()+F.quote(L);V=g(l);m=f.Addon().getAddonInfo(H)
	try:
		if len(V[Y])==0:time.sleep(15)
		R=B;M=B
		for A in V[Y]:
			D=e.ListItem(label=A['label']);D.setLabel2('hihi');C={}
			if Z in A:
				C=A[Z]
				if M==B and H in C:M=C[H]
				if H not in C:C[H]=m
			if P in A:
				D.setInfo('video',A[P])
				if R==B and a in A[P]:R=A[P][a]+'s'
			N=O
			if b in A:D.setProperty('IsPlayable','true');D.setPath(A[b])
			else:N=True
			if c not in C:C[c]='DefaultFolder.png'if N else'DefaultVideo.png'
			D.setArt(C)
			if d in A:n=A[d];o=F.urlencode({W:n});K=F.urlunsplit((X,T,'/',o,B))
			E.addDirectoryItem(G,K if N else D.getPath(),D,N)
		if R:E.setContent(G,'episodes')
		if M:E.setPluginFanart(G,M)
	finally:E.endOfDirectory(G)
def G(txt):I.log(txt,I.LOGINFO)
def g(url,data=None,headers={}):return json.loads(A.urlopen(A.Request(url,data,headers)).read())
def H(url,data=None):
	try:B=A.urlopen(url,data)
	except C.error.HTTPError as D:B=D
	return B
class D(A.HTTPRedirectHandler):
	def redirect_request(A,req,fp,code,msg,headers,newurl):0
A.install_opener(A.build_opener(D))
if __name__=='__main__':B()