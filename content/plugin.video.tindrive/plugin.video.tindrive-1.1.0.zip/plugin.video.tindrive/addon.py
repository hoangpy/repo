U='Enter Passcode'
K=False
A=''
import xbmcplugin as B,xbmcgui as I,xbmc as N,json,sys as J,time,xbmcaddon as j,urllib.parse as F
from req import get_json as k,get,post_json as G,set_token as H
T='https://phim.nghien.workers.dev'
def C():
	i='path';h='mediatype';g='info';f='art';e='plugin';d='subdir';c='verify_passcode';b='action';S='icon';R='/';H='fanart';C=int(J.argv[1]);q=J.argv[0];m,V,r,n,m=F.urlsplit(J.argv[0]+J.argv[2]);W=dict(F.parse_qsl(n))
	if W.get(b)==c:
		if l():N.executebuiltin('Container.Refresh')
		B.endOfDirectory(C);return
	O=W.get(d,A);P=T+'/kodi/drive'
	if O!=A:P=P+R+F.quote(O,safe=A)
	X=k(P);o=j.Addon().getAddonInfo(H)
	try:
		Y=A;L=A
		if O==A:p=F.urlunsplit((e,V,R,F.urlencode({b:c}),A));Z=I.ListItem(label=U);Z.setArt({S:'DefaultAddonService.png'});B.addDirectoryItem(C,p,Z,K)
		for D in X['items']:
			G=I.ListItem(label=D['label']);E={}
			if f in D:
				E=D[f]
				if L==A and H in E:L=E[H]
				if H not in E:E[H]=o
			if g in D:
				M={B:A for(B,A)in D[g].items()if A is not None}
				if M:G.setInfo('video',M)
				if Y==A and h in M:Y=M[h]+'s'
			Q=bool(D.get('isFolder'))
			if Q:a=F.urlunsplit((e,V,R,F.urlencode({d:D[i]}),A))
			else:G.setProperty('IsPlayable','true');G.setPath(D.get(i,A));a=G.getPath()
			if S not in E:E[S]='DefaultFolder.png'if Q else'DefaultVideo.png'
			G.setArt(E);G.setDateTime(D['dateTime']);B.addDirectoryItem(C,a,G,Q)
		B.setContent(C,'episodes');B.setPluginCategory(C,X['dirName'])
		if L:B.setPluginFanart(C,L)
		B.addSortMethod(C,B.SORT_METHOD_LABEL);B.addSortMethod(C,B.SORT_METHOD_DATE,label2Mask='%I')
	finally:B.endOfDirectory(C)
def l():
	E='Passcode';B=I.Dialog();C=B.input(U,type=I.INPUT_NUMERIC)
	if not C:return K
	try:
		F=G(T+'/kodi/token',{'passcode':C});D=F.get('token',A)
		if D:H(D);return True
		else:B.ok(E,'Verification failed: no token received.');return K
	except Exception as J:B.ok(E,'Error: '+str(J));return K
def D(txt):N.log(txt,N.LOGINFO)
if __name__=='__main__':C()