import json
import urllib
from urllib import request

import xbmcaddon
import xbmcgui

_WINDOW = xbmcgui.Window(10000)
_TOKEN_KEY = "plugin.video.tindrive.token"


def get_token() -> str:
    token = _WINDOW.getProperty(_TOKEN_KEY)
    if not token:
        token = xbmcaddon.Addon().getSetting("token")
        if token:
            _WINDOW.setProperty(_TOKEN_KEY, token)
    return token


def set_token(token: str):
    _WINDOW.setProperty(_TOKEN_KEY, token)
    xbmcaddon.Addon().setSetting("token", token)


def _auth_headers() -> dict:
    token = get_token()
    if token:
        return {"Authorization": token}
    return {}


def get_json(url: str, data=None, extra_headers: dict = {}):
    h = {"user-agent": "okhttp/1.2"}
    h.update(_auth_headers())
    h.update(extra_headers)
    return json.loads(request.urlopen(request.Request(url, data, h)).read())


def post_json(url: str, payload: dict, extra_headers: dict = {}):
    body = json.dumps(payload).encode("utf-8")
    h = {"Content-Type": "application/json", "user-agent": "okhttp/1.2"}
    h.update(_auth_headers())
    h.update(extra_headers)
    req = request.Request(url, data=body, headers=h, method="POST")
    return json.loads(request.urlopen(req).read())


def get(url: str, data=None):
    try:
        h = {"user-agent": "okhttp/1.2"}
        h.update(_auth_headers())
        req = request.Request(url, data, h)
        r = request.urlopen(req)
    except urllib.error.HTTPError as e:
        r = e

    return r


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


request.install_opener(request.build_opener(NoRedirect))
