export interface ListItemArt {
  thumb?: string;
  poster?: string;
  banner?: string;
  fanart?: string;
  clearart?: string;
  clearlogo?: string;
  landscape?: string;
  icon?: string;
  /** Season-specific poster, e.g. "season.1.poster" */
  [key: string]: string | undefined;
}

/** Minimal video info — only mediatype is accessed in addon.py */
export interface ListItemVideoInfo {
  mediatype?: string;
  [key: string]: unknown;
}

/** Minimal xbmcgui.ListItem — shaped like kodi.listitem.ts, limited to addon.py usage */
export interface ListItem {
  label: string;
  path?: string;
  art?: ListItemArt;
  videoInfo?: ListItemVideoInfo;
  /** Arbitrary properties, e.g. { IsPlayable: "true" } */
  properties?: Record<string, string>;
  // ---- setIsFolder ---------------------------------------------------------
  isFolder?: boolean;
  // ---- setDateTime ---------------------------------------------------------
  /** ISO 8601 date-time string */
  dateTime?: string;
}
