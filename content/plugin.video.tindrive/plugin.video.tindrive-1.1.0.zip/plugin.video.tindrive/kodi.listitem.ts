/**
 * Official Kodi xbmcgui.ListItem TypeScript types
 * Source: https://codedocs.xyz/xbmc/xbmc/classXBMCAddon_1_1xbmcgui_1_1ListItem.html
 */

// ---------------------------------------------------------------------------
// Supporting types
// ---------------------------------------------------------------------------

/** xbmc.Actor — passed to InfoTagVideo.setCast() / ListItem.setCast() */
export interface Actor {
  name: string;
  role?: string;
  /** Sort order in cast list */
  order?: number;
  thumbnail?: string;
}

/** xbmc.VideoStreamDetail — passed to InfoTagVideo.addVideoStream() */
export interface VideoStreamDetail {
  width?: number;
  height?: number;
  /** Pixel aspect ratio */
  aspect?: number;
  /** Duration in seconds */
  duration?: number;
  codec?: string;
  stereomode?: string;
  language?: string;
  hdrtype?: string;
}

/** xbmc.AudioStreamDetail — passed to InfoTagVideo.addAudioStream() */
export interface AudioStreamDetail {
  channels?: number;
  codec?: string;
  language?: string;
}

/** xbmc.SubtitleStreamDetail — passed to InfoTagVideo.addSubtitleStream() */
export interface SubtitleStreamDetail {
  language?: string;
}

// ---------------------------------------------------------------------------
// InfoTagVideo
// Source: https://codedocs.xyz/xbmc/xbmc/classXBMCAddon_1_1xbmc_1_1InfoTagVideo.html
// ---------------------------------------------------------------------------

export interface InfoTagVideo {
  /** Internal database id */
  dbId?: number;
  mediaType?: string;
  title?: string;
  originalTitle?: string;
  sortTitle?: string;
  tvShowTitle?: string;
  tvShowStatus?: string;
  tagLine?: string;
  plot?: string;
  plotOutline?: string;
  /** URL of thumbnail/poster image */
  pictureURL?: string;
  imdbnumber?: string;
  trailer?: string;
  /** MPAA / age rating */
  mpaa?: string;
  year?: number;
  season?: number;
  episode?: number;
  /** Sort override for episode number */
  sortEpisode?: number;
  /** Sort override for season number */
  sortSeason?: number;
  top250?: number;
  setId?: number;
  trackNumber?: number;
  /** Duration in seconds */
  duration?: number;
  playcount?: number;
  userrating?: number;
  /** ISO 8601 date string */
  premiered?: string;
  /** ISO 8601 date string */
  firstAired?: string;
  /** ISO 8601 date string */
  lastPlayed?: string;
  /** ISO 8601 date string */
  dateAdded?: string;
  productionCode?: string;
  episodeGuide?: string;
  set?: string;
  setOverview?: string;
  album?: string;
  /** Resume position in seconds */
  resumeTime?: number;
  resumeTimeTotal?: number;
  votes?: number;
  genres?: string[];
  directors?: string[];
  writers?: string[];
  studios?: string[];
  countries?: string[];
  tags?: string[];
  showLinks?: string[];
  artists?: string[];
  cast?: Actor[];
  /** Named seasons: [number, name] pairs */
  seasons?: [number, string][];
  /** Map of rating type → [score, votes] */
  ratings?: Record<string, [number, number]>;
  /** Default rating type key */
  defaultRating?: string;
  /** Map of id type → unique id value */
  uniqueIDs?: Record<string, string>;
  /** Default unique id type key */
  defaultUniqueID?: string;
  videoStreams?: VideoStreamDetail[];
  audioStreams?: AudioStreamDetail[];
  subtitleStreams?: SubtitleStreamDetail[];
  path?: string;
  filenameAndPath?: string;
  videoAssetTitle?: string;
}

// ---------------------------------------------------------------------------
// InfoTagMusic
// Source: https://codedocs.xyz/xbmc/xbmc/classXBMCAddon_1_1xbmc_1_1InfoTagMusic.html
// ---------------------------------------------------------------------------

export interface InfoTagMusic {
  dbId?: number;
  mediaType?: string;
  url?: string;
  title?: string;
  artist?: string;
  album?: string;
  albumArtist?: string;
  genres?: string[];
  /** Duration in seconds */
  duration?: number;
  year?: number;
  /** ISO 8601 date string */
  releaseDate?: string;
  track?: number;
  disc?: number;
  rating?: number;
  userrating?: number;
  listeners?: number;
  playcount?: number;
  /** ISO 8601 date string */
  lastPlayed?: string;
  comment?: string;
  lyrics?: string;
  musicBrainzTrackID?: string;
  musicBrainzArtistID?: string[];
  musicBrainzAlbumID?: string;
  musicBrainzReleaseGroupID?: string;
  musicBrainzAlbumArtistID?: string[];
  songVideoURL?: string;
}

// ---------------------------------------------------------------------------
// InfoTagPicture
// Source: https://codedocs.xyz/xbmc/xbmc/classXBMCAddon_1_1xbmc_1_1InfoTagPicture.html
// ---------------------------------------------------------------------------

export interface InfoTagPicture {
  /** e.g. "1920x1080" */
  resolution?: string;
  /** ISO 8601 date-time string */
  dateTimeTaken?: string;
}

// ---------------------------------------------------------------------------
// ListItem art dictionary
// Keys are free-form strings; common ones are listed below.
// Source: https://kodi.wiki/view/InfoLabels#ListItem.Art(type)
// ---------------------------------------------------------------------------

export interface ListItemArt {
  thumb?: string;
  poster?: string;
  banner?: string;
  fanart?: string;
  clearart?: string;
  clearlogo?: string;
  landscape?: string;
  icon?: string;
  /** Season-specific poster, e.g. "season.1.poster" */
  [key: string]: string | undefined;
}

// ---------------------------------------------------------------------------
// Available fanart entry — used in ListItem.setAvailableFanart()
// ---------------------------------------------------------------------------

export interface AvailableFanartEntry {
  image: string;
  preview?: string;
  colors?: string;
}

// ---------------------------------------------------------------------------
// ListItem constructor options
// ---------------------------------------------------------------------------

export interface ListItemOptions {
  label?: string;
  label2?: string;
  path?: string;
  /** When true, item is not added to the Kodi library (faster for large lists) */
  offscreen?: boolean;
}

// ---------------------------------------------------------------------------
// xbmcgui.ListItem
// Source: https://codedocs.xyz/xbmc/xbmc/classXBMCAddon_1_1xbmcgui_1_1ListItem.html
// ---------------------------------------------------------------------------

export interface ListItem {
  // ---- Constructor fields --------------------------------------------------
  label: string;
  label2?: string;
  path?: string;
  offscreen?: boolean;

  // ---- setArt / getArt -----------------------------------------------------
  art?: ListItemArt;

  // ---- setInfo('video', ...) -----------------------------------------------
  videoInfo?: InfoTagVideo;

  // ---- setInfo('music', ...) -----------------------------------------------
  musicInfo?: InfoTagMusic;

  // ---- setInfo('pictures', ...) --------------------------------------------
  pictureInfo?: InfoTagPicture;

  // ---- setCast -------------------------------------------------------------
  cast?: Actor[];

  // ---- setRating / setUniqueIDs --------------------------------------------
  ratings?: Record<string, { rating: number; votes?: number; isDefault?: boolean }>;
  uniqueIDs?: Record<string, string>;

  // ---- addSeason -----------------------------------------------------------
  seasons?: { number: number; name?: string }[];

  // ---- setAvailableFanart --------------------------------------------------
  availableFanart?: AvailableFanartEntry[];

  // ---- addStreamInfo (legacy API, prefer InfoTagVideo stream methods) -------
  streamInfo?: {
    video?: Partial<VideoStreamDetail>[];
    audio?: Partial<AudioStreamDetail>[];
    subtitle?: Partial<SubtitleStreamDetail>[];
  };

  // ---- setProperty / setProperties -----------------------------------------
  /** Arbitrary key-value properties, e.g. { IsPlayable: "true" } */
  properties?: Record<string, string>;

  // ---- setMimeType ---------------------------------------------------------
  mimeType?: string;

  // ---- setSubtitles --------------------------------------------------------
  subtitles?: string[];

  // ---- setIsFolder ---------------------------------------------------------
  isFolder?: boolean;

  // ---- setDateTime ---------------------------------------------------------
  /** ISO 8601 date-time string */
  dateTime?: string;

  // ---- addContextMenuItems -------------------------------------------------
  contextMenuItems?: [label: string, action: string][];
  replaceContextMenuItems?: boolean;
}
